"""One scheduler tick for the Synology NAS (nas/tick.sh, every 10 minutes).

Same schedule as deploy/render_worker.py, but run-once: the NAS Task Scheduler starts
it, it does whatever is due and exits. Markers live in state/live/, which a new package
never overwrites.
  * start-up check (`server_run.sh --check-only`): after a new package, and at most once
    a day until the order check has passed, so a failing check never repeats every tick.
  * 00:10-02:00 UTC: today's daily run, once.
  * minute >= 40: this hour's safety check, once.
  * 12:00-12:59 UTC: automatic update check, once a day (far from the 00:10 trade run).
    A new version is downloaded, its checksum checked, and its own self-test run in a
    separate folder; only if that passes is it installed. Otherwise the current version
    keeps running. state/ and logs/ are never touched.
"""
from __future__ import annotations

import datetime as dt
import importlib.util
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
STATE = ROOT / "state" / "live"
_spec = importlib.util.spec_from_file_location("render_worker", ROOT / "deploy" / "render_worker.py")
rw = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rw)


def _read(name: str) -> str | None:
    try:
        return (STATE / name).read_text().strip() or None
    except OSError:
        return None


def _write(name: str, value: str) -> None:
    (STATE / name).write_text(value + "\n")


def package_version() -> str:
    try:
        return (ROOT / "nas" / "VERSION").read_text().strip()
    except OSError:
        return "unknown"


def order_check_passed() -> bool:
    import json
    try:
        return bool(json.loads((STATE / "order_check.json").read_text()).get("passed"))
    except (OSError, ValueError, AttributeError):
        return False


def check_due(now: dt.datetime, version: str, last: str | None, passed: bool) -> bool:
    """last is 'version date' of the previous start-up check."""
    if not last:
        return True
    lv, _, ld = last.partition(" ")
    if lv != version:
        return True
    return not passed and ld != now.date().isoformat()


def run(script: str, *args: str) -> tuple[int, str]:
    env = dict(os.environ, PY=os.environ.get("PY", sys.executable))
    rw.log(f"start {script} {' '.join(args)}".rstrip())
    p = subprocess.run(["bash", f"deploy/{script}", *args], cwd=ROOT, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(p.stdout, end="", flush=True)
    rw.log(f"done {script} (exit {p.returncode})")
    return p.returncode, p.stdout


def self_test() -> tuple[bool, str]:
    p = subprocess.run([os.environ.get("PY", sys.executable), "-m", "unittest", "discover", "-s", "tests"],
                       cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    tail = p.stdout.strip().splitlines()[-3:]
    return p.returncode == 0, " / ".join(tail)


def write_status(now: dt.datetime, lines: list[str]) -> None:
    """Short status file next to the uploaded package, so the person can open it in
    File Station without a terminal. Never contains the key."""
    d = os.environ.get("TB_STATUS_DIR")
    if not d:
        return
    text = [f"Trading bot op de NAS, {now:%Y-%m-%d %H:%M} UTC, pakket {package_version()}", *lines]
    try:
        pathlib.Path(d, "trading-bot-STATUS.txt").write_text("\n".join(text) + "\n")
    except OSError:
        pass


UPDATE_URL = os.environ.get(
    "TB_UPDATE_URL", "https://raw.githubusercontent.com/wdhens/trading-bot-nas/main/latest.json")
UPDATE_HOUR = 12


def update_due(now: dt.datetime, last_date: str | None) -> bool:
    return now.hour == UPDATE_HOUR and last_date != now.date().isoformat()


def _safe_members(tf):
    for m in tf.getmembers():
        name = m.name
        if name.startswith("/") or ".." in pathlib.PurePosixPath(name).parts:
            raise ValueError(f"unsafe path in package: {name}")
        if pathlib.PurePosixPath(name).parts[:2] in ((".", "state"), (".", "logs")) or \
                pathlib.PurePosixPath(name).parts[:1] in (("state",), ("logs",)):
            continue  # a package never overwrites live state or logs
        yield m


def extract(tgz: pathlib.Path, dest: pathlib.Path) -> None:
    import tarfile
    with tarfile.open(tgz, "r:gz") as tf:
        tf.extractall(dest, members=list(_safe_members(tf)))


def check_update(now: dt.datetime) -> str:
    """Returns a one-line result for the log and the status file."""
    import hashlib
    import json
    import shutil
    import urllib.request
    with urllib.request.urlopen(UPDATE_URL, timeout=60) as r:
        m = json.load(r)
    current = package_version()
    if m.get("version") == current:
        return f"update: {package_version()} is the newest version"
    work = ROOT.parent / "trading-bot-update"
    shutil.rmtree(work, ignore_errors=True)
    (work / "code").mkdir(parents=True)
    tgz = work / "new.tgz"
    h = hashlib.sha256()
    with urllib.request.urlopen(m["url"], timeout=300) as r, open(tgz, "wb") as f:
        while chunk := r.read(1 << 20):
            h.update(chunk)
            f.write(chunk)
    if h.hexdigest() != m.get("sha256"):
        shutil.rmtree(work, ignore_errors=True)
        return f"update {m.get('version')}: checksum wrong, NOT installed"
    extract(tgz, work / "code")
    py = work / "code" / "nas" / "python"
    os.chmod(py, 0o755)
    py = os.environ.get("TB_SELFTEST_PY") or py  # rehearsals only
    for ld in (work / "code" / "runtime" / "lib").glob("*/ld-linux-*"):
        os.chmod(ld, 0o755)
    p = subprocess.run([str(py), "-m", "unittest", "discover", "-s", "tests"], cwd=work / "code",
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        tail = " / ".join(p.stdout.strip().splitlines()[-3:])
        shutil.rmtree(work, ignore_errors=True)
        return f"update {m.get('version')}: self-test failed, NOT installed ({tail})"
    prev = ROOT / ".installed.tgz"
    if prev.exists():
        prev.replace(ROOT / ".previous.tgz")
    extract(tgz, ROOT)
    shutil.move(str(tgz), str(prev))
    shutil.rmtree(work, ignore_errors=True)
    return f"update: installed {m.get('version')} (was {current}); self-test passed"


KEEP = ("PASS", "FAIL", "LIVE", "KEY", "ALL CHECKS", "order check", "cycle OK", "!!", "Error", "error")


def main() -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    now = dt.datetime.now(dt.timezone.utc)
    version = package_version()
    passed = order_check_passed()
    if check_due(now, version, _read("last_check.txt"), passed):
        _write("last_check.txt", f"{version} {now.date().isoformat()}")
        rw.log(f"package {version}: start-up check")
        ok, summary = self_test()
        rw.log(f"self-test {'OK' if ok else 'FAILED'}: {summary}")
        if not ok:
            write_status(now, ["ZELFTEST MISLUKT (er zijn geen orders geplaatst):", summary])
            return
        _, out = run("server_run.sh", "--check-only")
        write_status(now, ["zelftest OK"] + [l for l in out.splitlines() if any(k in l for k in KEEP)][-15:])
    if rw.daily_due(now, _read("last_daily.txt")):
        _write("last_daily.txt", now.date().isoformat())
        _, out = run("server_run.sh")
        write_status(now, ["dagelijkse run"] + [l for l in out.splitlines() if any(k in l for k in KEEP)][-15:])
    elif rw.safety_due(now, _read("last_safety.txt")):
        _write("last_safety.txt", now.strftime("%Y-%m-%dT%H"))
        run("server_safety.sh")
    elif update_due(now, _read("last_update.txt")):
        _write("last_update.txt", now.date().isoformat())
        try:
            msg = check_update(now)
        except Exception as e:  # network down, GitHub unreachable: try again tomorrow
            msg = f"update check failed: {e}"
        rw.log(msg)
        if "installed" in msg or "NOT" in msg:
            write_status(now, [msg])
    _write("last_tick.txt", now.isoformat(timespec="seconds"))


if __name__ == "__main__":
    main()

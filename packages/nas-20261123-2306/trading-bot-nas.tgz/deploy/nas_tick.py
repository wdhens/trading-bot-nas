"""One scheduler tick for the Synology NAS (nas/tick.sh, every 10 minutes).

Same schedule as deploy/render_worker.py, but run-once: the NAS Task Scheduler starts
it, it does whatever is due and exits. Markers live in state/live/, which a new package
never overwrites.
  * start-up check (`server_run.sh --check-only`): after a new package, and at most once
    a day until the order check has passed, so a failing check never repeats every tick.
  * 00:10-02:00 UTC: today's daily run, once.
  * minute >= 40: this hour's safety check, once.
  * 10 min to 3 h after the US cash close on US trading days (21:10 UTC in winter, 20:10 in
    summer): the real-money index dip step (`python -m indexdip live`), once per close.
  * after the safety check, unless a trading moment is < 60 min away: the Lighter pool step
    (`python -m pool live`); before a trading run, the pool's cash comes out of the LLP first
    (`pool live pre`, the run waits a tick for Lighter's 5-minute cooldown, at most 40 min).
  * 03/06/09/12/15/18 UTC: automatic update check, once per slot (far from the 00:10 trade run and
    the index run).
    A new version is downloaded, its checksum checked, and its own self-test run in a
    separate folder; only if that passes is it installed. Otherwise the current version
    keeps running. state/ and logs/ are never touched.
"""
from __future__ import annotations

import datetime as dt
import importlib.util
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
STATE = ROOT / "state" / "live"
_spec = importlib.util.spec_from_file_location("render_worker", ROOT / "deploy" / "render_worker.py")
rw = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rw)


def _read(name: str) -> str | None:
    try:
        return (STATE / name).read_text().strip() or None
    except OSError:
        return None


def _write(name: str, value: str) -> None:
    (STATE / name).write_text(value + "\n")


def package_version() -> str:
    try:
        return (ROOT / "nas" / "VERSION").read_text().strip()
    except OSError:
        return "unknown"


def order_check_passed() -> bool:
    import json
    try:
        return bool(json.loads((STATE / "order_check.json").read_text()).get("passed"))
    except (OSError, ValueError, AttributeError):
        return False


def check_due(now: dt.datetime, version: str, last: str | None, passed: bool) -> bool:
    """last is 'version date' of the previous start-up check."""
    if not last:
        return True
    lv, _, ld = last.partition(" ")
    if lv != version:
        return True
    return not passed and ld != now.date().isoformat()


def run(script: str, *args: str) -> tuple[int, str]:
    env = dict(os.environ, PY=os.environ.get("PY", sys.executable))
    rw.log(f"start {script} {' '.join(args)}".rstrip())
    p = subprocess.run(["bash", f"deploy/{script}", *args], cwd=ROOT, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(p.stdout, end="", flush=True)
    rw.log(f"done {script} (exit {p.returncode})")
    return p.returncode, p.stdout


def self_test() -> tuple[bool, str]:
    p = subprocess.run([os.environ.get("PY", sys.executable), "-m", "unittest", "discover", "-s", "tests"],
                       cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    tail = p.stdout.strip().splitlines()[-3:]
    if p.returncode != 0:
        return False, " / ".join(tail)
    # the unit tests run without Lighter's library; check it loads on this device too
    q = subprocess.run([os.environ.get("PY", sys.executable), "-c", "import lighter, yaml, aiohttp"],
                       cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if q.returncode != 0:
        return False, "lighter library does not load: " + " / ".join(q.stdout.strip().splitlines()[-2:])
    return True, " / ".join(tail)


def write_status(now: dt.datetime, lines: list[str]) -> None:
    """Short status file next to the uploaded package, so the person can open it in
    File Station without a terminal. Never contains the key."""
    d = os.environ.get("TB_STATUS_DIR")
    if not d:
        return
    text = [f"Trading bot op de NAS, {now:%Y-%m-%d %H:%M} UTC, pakket {package_version()}", *lines]
    try:
        pathlib.Path(d, "trading-bot-STATUS.txt").write_text("\n".join(text) + "\n")
    except OSError:
        pass


_ispec = importlib.util.spec_from_file_location("indexdip_rules", ROOT / "indexdip" / "__main__.py")
idx = importlib.util.module_from_spec(_ispec)
_ispec.loader.exec_module(idx)
INDEX_DELAY_MS = 10 * 60_000
INDEX_WINDOW_MS = 3 * 3_600_000


def index_close_due(now: dt.datetime, last: str | None) -> str | None:
    """The US close (ISO date) whose index step is due now, or None."""
    ms = int(now.timestamp() * 1000)
    for back in (0, 1):
        day = now.date() - dt.timedelta(days=back)
        if not idx.trading_day(day):
            continue
        ct = idx.us_close_ms(day)
        if ct + INDEX_DELAY_MS <= ms < ct + INDEX_WINDOW_MS and last != day.isoformat():
            return day.isoformat()
    return None


def pool_holds_cash() -> bool:
    """True if the last pool step left USDC in the LLP (or on its way back)."""
    import json
    try:
        st = json.loads((STATE / "pool.json").read_text())
    except (OSError, ValueError):
        return False
    return bool(st.get("llp_shares") or st.get("unlock_usdc"))


def near_trade(now: dt.datetime, minutes: int = 60) -> bool:
    """A trading moment (00:10 UTC daily run, index run 10 min after the US close) is less
    than `minutes` away: then no new cash goes into the LLP."""
    ms = int(now.timestamp() * 1000)
    soon = ms + minutes * 60_000
    nxt = dt.datetime.combine(now.date() + dt.timedelta(days=1), dt.time(0, 10), dt.timezone.utc)
    moments = [int(nxt.timestamp() * 1000)]
    for back in (0, 1):
        day = now.date() - dt.timedelta(days=back)
        if idx.trading_day(day):
            moments.append(idx.us_close_ms(day) + INDEX_DELAY_MS)
    return any(ms <= t <= soon for t in moments)


def run_pool(*args: str) -> tuple[int, str]:
    env = dict(os.environ, PY=os.environ.get("PY", sys.executable))
    rw.log(f"start pool live {' '.join(args)}".rstrip())
    p = subprocess.run([env["PY"], "-m", "pool", "live", *args], cwd=ROOT, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(p.stdout, end="", flush=True)
    rw.log(f"done pool live (exit {p.returncode})")
    return p.returncode, p.stdout


PRE_WAIT_S = 40 * 60


def pool_pre_blocks(now: dt.datetime) -> bool:
    """Before a trading run: take the cash out of the LLP. True = wait for the next tick
    (Lighter releases LLP cash after a 5-minute cooldown). Never waits more than 40 minutes."""
    if not pool_holds_cash():
        return False
    started = _read("pool_pre.txt")
    t = now.timestamp()
    if started and t - float(started) > PRE_WAIT_S:
        rw.log("pool: cash still in the LLP after 40 min; trading run goes ahead with what is free")
        return False
    if not started:
        _write("pool_pre.txt", str(t))
    code, _ = run_pool("pre")
    return code == 3


UPDATE_URL = os.environ.get(
    "TB_UPDATE_URL", "https://raw.githubusercontent.com/wdhens/trading-bot-nas/main/latest.json")
UPDATE_HOURS = (3, 6, 9, 12, 15, 18)    # UTC; never near the 00:10 daily run or the 21:10 index run


def update_slot(now: dt.datetime) -> str:
    return now.strftime("%Y-%m-%dT%H")


def update_due(now: dt.datetime, last: str | None) -> bool:
    """Once per slot (every 3 hours at most), so a fix is installed within 3 hours of publishing
    (was once a day at 12:xx, which left a fix waiting up to 24 hours)."""
    return now.hour in UPDATE_HOURS and last != update_slot(now)


def _is_runtime(name: str) -> bool:
    parts = pathlib.PurePosixPath(name).parts
    if parts[:1] == (".",):
        parts = parts[1:]
    return parts[:1] in (("runtime",), ("site",))


def _safe_members(tf, skip_runtime: bool = False):
    for m in tf.getmembers():
        name = m.name
        if name.startswith("/") or ".." in pathlib.PurePosixPath(name).parts:
            raise ValueError(f"unsafe path in package: {name}")
        if pathlib.PurePosixPath(name).parts[:2] in ((".", "state"), (".", "logs")) or \
                pathlib.PurePosixPath(name).parts[:1] in (("state",), ("logs",)):
            continue  # a package never overwrites live state or logs
        if skip_runtime and _is_runtime(name):
            continue  # never rewrite the Python we are running on (that corrupted it on 2026-11-21)
        yield m


def extract(tgz: pathlib.Path, dest: pathlib.Path, skip_runtime: bool = False) -> None:
    import tarfile
    with tarfile.open(tgz, "r:gz") as tf:
        tf.extractall(dest, members=list(_safe_members(tf, skip_runtime)))


def check_update(now: dt.datetime) -> str:
    """Returns a one-line result for the log and the status file."""
    import hashlib
    import json
    import shutil
    import urllib.request
    with urllib.request.urlopen(UPDATE_URL, timeout=60) as r:
        m = json.load(r)
    current = package_version()
    if m.get("version") == current:
        return f"update: {package_version()} is the newest version"
    work = ROOT.parent / "trading-bot-update"
    shutil.rmtree(work, ignore_errors=True)
    (work / "code").mkdir(parents=True)
    tgz = work / "new.tgz"
    h = hashlib.sha256()
    with urllib.request.urlopen(m["url"], timeout=300) as r, open(tgz, "wb") as f:
        while chunk := r.read(1 << 20):
            h.update(chunk)
            f.write(chunk)
    if h.hexdigest() != m.get("sha256"):
        shutil.rmtree(work, ignore_errors=True)
        return f"update {m.get('version')}: checksum wrong, NOT installed"
    extract(tgz, work / "code")
    py = work / "code" / "nas" / "python"
    os.chmod(py, 0o755)
    py = os.environ.get("TB_SELFTEST_PY") or py  # rehearsals only
    for ld in (work / "code" / "runtime" / "lib").glob("*/ld-linux-*"):
        os.chmod(ld, 0o755)
    p = subprocess.run([str(py), "-m", "unittest", "discover", "-s", "tests"], cwd=work / "code",
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode == 0:
        q = subprocess.run([str(py), "-c", "import lighter, yaml, aiohttp"], cwd=work / "code",
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if q.returncode != 0:
            p = q
    if p.returncode != 0:
        tail = " / ".join(p.stdout.strip().splitlines()[-3:])
        shutil.rmtree(work, ignore_errors=True)
        return f"update {m.get('version')}: self-test failed, NOT installed ({tail})"
    prev = ROOT / ".installed.tgz"
    if prev.exists():
        prev.replace(ROOT / ".previous.tgz")
    extract(tgz, ROOT, skip_runtime=True)   # code only: runtime/ and site/ change by manual upload
    shutil.move(str(tgz), str(prev))
    shutil.rmtree(work, ignore_errors=True)
    return f"update: installed {m.get('version')} (was {current}); self-test passed"


KEEP = ("POOL", "INDEX", "PASS", "FAIL", "LIVE", "KEY", "ALL CHECKS", "order check", "cycle OK", "!!", "Error", "error")


def main() -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    now = dt.datetime.now(dt.timezone.utc)
    version = package_version()
    passed = order_check_passed()
    if check_due(now, version, _read("last_check.txt"), passed):
        _write("last_check.txt", f"{version} {now.date().isoformat()}")
        rw.log(f"package {version}: start-up check")
        ok, summary = self_test()
        rw.log(f"self-test {'OK' if ok else 'FAILED'}: {summary}")
        if not ok:
            write_status(now, ["ZELFTEST MISLUKT (er zijn geen orders geplaatst):", summary])
            return
        _, out = run("server_run.sh", "--check-only")
        write_status(now, ["zelftest OK"] + [l for l in out.splitlines() if any(k in l for k in KEEP)][-15:])
    trade_due = rw.daily_due(now, _read("last_daily.txt")) or index_close_due(now, _read("last_index.txt"))
    if trade_due and pool_holds_cash() and pool_pre_blocks(now):
        _write("last_tick.txt", now.isoformat(timespec="seconds"))
        return
    if trade_due:
        try:
            (STATE / "pool_pre.txt").unlink()
        except OSError:
            pass
    if rw.daily_due(now, _read("last_daily.txt")):
        _write("last_daily.txt", now.date().isoformat())
        _, out = run("server_run.sh")
        write_status(now, ["dagelijkse run"] + [l for l in out.splitlines() if any(k in l for k in KEEP)][-15:])
    elif index_close_due(now, _read("last_index.txt")):
        _write("last_index.txt", index_close_due(now, _read("last_index.txt")))
        env = dict(os.environ, PY=os.environ.get("PY", sys.executable))
        rw.log("start indexdip live")
        p = subprocess.run([env["PY"], "-m", "indexdip", "live"], cwd=ROOT, env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print(p.stdout, end="", flush=True)
        rw.log(f"done indexdip live (exit {p.returncode})")
        write_status(now, ["index-dip run"] + [l for l in p.stdout.splitlines() if "INDEX" in l][-10:])
    elif rw.safety_due(now, _read("last_safety.txt")):
        _write("last_safety.txt", now.strftime("%Y-%m-%dT%H"))
        run("server_safety.sh")
        if not near_trade(now):
            code, out = run_pool()
            crashed = code not in (0, 3) or "Traceback" in out
            if crashed:
                write_status(now, ["pool: FOUT, geen orders van de pool"] + out.strip().splitlines()[-10:])
            elif "POOL" in out and ("FAILED" in out or "STOPPED" in out or "action(s)" in out and " 0 action" not in out):
                write_status(now, ["pool"] + [l for l in out.splitlines() if "POOL" in l][-8:])
    elif update_due(now, _read("last_update.txt")):
        _write("last_update.txt", update_slot(now))
        try:
            msg = check_update(now)
        except Exception as e:  # network down, GitHub unreachable: try again tomorrow
            msg = f"update check failed: {e}"
        rw.log(msg)
        if "installed" in msg or "NOT" in msg:
            write_status(now, [msg])
    _write("last_tick.txt", now.isoformat(timespec="seconds"))
    # research recorder, last and best effort: never before or instead of a trading step
    used = (dt.datetime.now(dt.timezone.utc) - now).total_seconds()
    if used < 120 and not os.environ.get("TB_NO_RECORDER"):
        try:
            spec = importlib.util.spec_from_file_location("book_recorder", ROOT / "deploy" / "book_recorder.py")
            br = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(br)
            br.main(budget_s=60)
        except Exception as e:
            rw.log(f"book recorder skipped: {type(e).__name__}")


if __name__ == "__main__":
    main()
